<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop ">
    
<div id="fonPushProfit">
    <div class="backdrop-message">
		<strong>FlashPlayer</strong> заблокировал воспроизведение видео в вашем браузере. Нажмите <strong>&quot;Разрешить&quot;</strong>
		, чтобы начать просмотр.	</div>
</div>
<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
	<tr>
        <td>
            <a href="#"><img border="0" src="images/player0dac.jpg?b=10" width="100%" height="100%"></a>
        </td>
    </tr>
</table>

</body>
</html>