<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop ">
    
<div class="w">
    <div class="cnt">
        <object class="cnt__ic" type="image/svg+xml" data="images/flash.svg?b=10"></object>
        <div class="cnt__tx"><strong>FlashPlayer</strong>
            заблокировал воспроизведение видео в вашем браузере. Нажмите            <strong>&quot;Разрешить&quot;</strong>
            , чтобы начать просмотр.        </div>
    </div>
    <div class="plr">
        <div class="plr__vw"></div>
        <div class="plr__ctl">
            <div class="plr__ctlL">
                <object class="plr__ctlIc" type="image/svg+xml" data="images/play.svg?b=10"></object>
                <div class="plr__ctlTm">0:00 / 12:43</div>
            </div>
            <div class="plr__ctlR">
                <object class="plr__ctlIc" type="image/svg+xml" data="images/sound.svg?b=10"></object>
                <object class="plr__ctlIc" type="image/svg+xml" data="images/full.svg?b=10"></object>
                <object class="plr__ctlIc" type="image/svg+xml" data="images/options.svg?b=10"></object>
            </div>
            <div class="plr__ctlLine"></div>
        </div>
        <div class="wLdg">
            <object class="wLdg__ic" type="image/svg+xml" data="images/loading.svg?b=10"></object>
            <div class="ldg">
                <div class="ldg__i"></div>
                <div class="ldg__i"></div>
                <div class="ldg__i"></div>
                <div class="ldg__i"></div>
            </div>
        </div>
    </div>
</div>

</body>
</html>