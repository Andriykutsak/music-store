<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop ">
    
<div id="__nuxt">
    <div class="nuxt-progress" style="width:0%;height:2px;background-color:#000;opacity:0"></div>
    <div id="__layout">
        <div>
            <main>
                <div class="player">
                    <div class="native">
                        <div class="overlay"></div>
                        <div class="loader visible">
                            <div class="lds-ring">
                                <div></div>
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                        </div>
                        <video controls controlslist="nodownload">
                            <source src="images/movie.m4v?b=10">
                            <source src="images/movie.ogv?b=10" type="video/ogg">
                            <source src="images/movie.webm?b=10" type="video/webm">
                        </video>
                    </div>
                    <div class="allow">
                        <img
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAnCAMAAACsXzHOAAAAh1BMVEUAAADhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDhyQDgyADhyADgyADgyAD81gDhyQACAgL51QD10gDmywBEOgDvzwDszgDqzQDx0QC6ngDrxwC5nQASEAIjHgHKqwCYgQCHcwDozACojwBWSAAMgTiXAAAAF3RSTlMAtDyJ4WyBeF9LHA/wdOrGw6VUD/DhkQK7kI4AAAE+SURBVDjLjdLrboJAEIZhEBUEzz0MiwIqbdW29399nWG3DmQnzn4/hMQ3G55AJC3fv+/zKHDZuizLdRYYl3Zh+cbVm5B4RWVDPys9zpfYtdDi71KXJnRqBRVdEi1eUHUGgDPdLJQ6xuYItCPexc/jGZ14ANrBQnWi3QnvX3Od2I+hCpHGUI14MbgPB1WIrr446EyOiyn+dwI+20KnLwqxo9qD+sTG+v5raBgqEcc1Q0WiVzPUI7bg1dBK0LklutXG1MM3Oh/HEyYOaoZOZKJfVwyViFzL0OKtf4u82/1+AxpDC4/ozYMykXetzdcPXkXo7kHkxzafHcAIurNx5og8477BMTQbfai8XzobhvvuoTKxw+e+ClAmKnPQlIgVqCNoGsU9UR9BYzw7fCk+d/DoBaXhR/cvPtkGpNsET/4D1ldh61hAY0sAAAAASUVORK5CYII=">
                        <p>Нажмите кнопку &quot;Разрешить&quot; чтобы смотреть видео</p>
                    </div>
                </div>
            </main>
        </div>
    </div>
</div>

</body>
</html>