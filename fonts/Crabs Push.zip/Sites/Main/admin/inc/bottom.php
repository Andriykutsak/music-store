<footer id="footer">
<div class="row">
<div class="col-lg-12">
<p><a href="tg://resolve?domain=crabs_channel">Канал Крабса в телеграм</a></p>
</div>
</div>
</footer>

</div>
<script type="text/javascript">var crabs_tkn = '<?php echo crabs_token(); ?>';</script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/bootstrap-datepicker.ru.min.js"></script>
<script src="js/custom.js"></script>
<script src="//cdn.datatables.net/plug-ins/1.10.19/sorting/date-de.js"></script>
</body>
</html>