<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop">
    
<div class="slider" id="slider">
    <div class="slider__it" style="background-image:url(images/slide10dac.jpg)"></div>
</div>

<div class="cnt">
	<div class="cnt__arrow"></div>
	<div class="cnt__tx">
		<div class="cnt__txDescr">Самый горячий контент ЗДЕСЬ</div>
		<div class="cnt__txT">Нажми &quot;Разрешить&quot; для просмотра</div>
	</div>
</div>

</body>
</html>