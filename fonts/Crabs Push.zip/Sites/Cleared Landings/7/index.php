<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/mainf1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop ">
    ﻿
<div class="push-arrow-wrap">
    <img src="images/arrow0dac.png?b=10" alt="arrow" class="push-arrow">
</div>
<div class="message">
    <div class="message__content">
        Если тебе исполнилось 18<br>нажми на кнопку &quot;Разрешить&quot;    </div>
</div>

</body>
</html>