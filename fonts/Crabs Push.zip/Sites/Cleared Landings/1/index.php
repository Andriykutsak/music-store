<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop">
    
<div class="block-center">
    <div class="block-center-left"></div>
    <div class="block-center-header">Я не робот</div>
    <div class="block-center-text">Нажмите на <b>Разрешить</b> для подтверждения, что вы не робот</div>
    <div class="block-center-right"></div>
</div>

<div id="popup" class="popup">
    <div class="popup-box">
        <p><b>Нажмите &quot;Разрешить&quot;, чтобы закрыть это окно</b></p>
        <p style="font-size: 14px">Это окно можно закрыть нажатием &quot;Разрешить&quot;. Если вы хотите продолжить действия на данном сайте, просто нажмите на подробную информацию.</p>
        <p style="color: #009cff; font-size: 14px">Подробная информация</p>
    </div>
</div>
<div class="left-notice"> Нажмите <span style="color: #197aec">Разрешить</span> чтобы подтвердить</div>

</body>
</html>