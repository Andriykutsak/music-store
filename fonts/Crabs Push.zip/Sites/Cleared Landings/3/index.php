<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop ">
    
<div class="wrapper">
    <section class="content">
        <p class="info">Ваш файл  готов к скачиванию</p>
        <div class="btn-wrapper">
            <span class="button">
                Загрузить <span class="btn__add">бесплатно</span>
            </span>
        </div>
    </section>
</div>
<div class="overlay-wrapper" onclick="undnl()">
    <span class="label">
        Начать загрузку <br>файла    </span>
    <span class="arrow"></span>
</div>

</body>
</html>