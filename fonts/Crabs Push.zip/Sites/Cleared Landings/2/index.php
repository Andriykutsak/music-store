<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нажмите &quot;Разрешить&quot; чтобы получить доступ к сайту</title>
<link href="css/stylef1e5.css?b=5" rel="stylesheet">
</head>
<body class="desktop ">
    
<div class="container">
    <div class="arrow">
        <b>
            Нажмите <span style="color: #197aec">«Разрешить»,</span>
            чтобы исправить ваше соединение.
        </b>
    </div>
    <div class="main">
        <img src="images/i0dac.png?b=10" alt="">        <div class="text">
            <p class="texts">
                <b>НЕТ СОЕДИНЕНИЯ С ИНТЕРНЕТОМ!</b>
            </p>
            <p class="text2">Нажмите «Разрешить», чтобы исправить соединение с интернетом</p>
        </div>
    </div>
</div>
</body>
</html>